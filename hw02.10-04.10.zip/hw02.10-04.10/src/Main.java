import java.util.Scanner;

// 1 уровень сложности: №1
//Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв (проверьте количество букв в слове).
//Нужно получить слово, состоящее из первой половины первого слова и второй половины второго слова. распечатать на консоль.
//Например:
//ввод - mama, papa
//вывод - mapa
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите первое слово (четное количество букв):");
        String word1 = scanner.next();

        System.out.println("Введите второе слово (четное количество букв):");
        String word2 = scanner.next();

        if (word1.length() % 2 == 0 && word2.length() % 2 == 0) {
            int halfLength1 = word1.length() / 2;
            int halfLength2 = word2.length() / 2;

            String result = word1.substring(0, halfLength1) + word2.substring(halfLength2);
            System.out.println("Результат: " + result);
        } else {
            System.out.println("Оба слова должны содержать четное количество букв.");
        }

        scanner.close();
        }
    }

    //№2
//            Реализовать программу, выводящую на экран результаты:
//            Сложения двух чисел
//            Вычитания двух чисел
//            Умножения двух чисел
//            Деления двух чисел
//            Каждая из арифметических операций должна быть реализована как отдельный метод.
