package hw02okt;

import java.util.Scanner;

public class ArithmeticOperations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите первое число:");
        double num1 = scanner.nextDouble();

        System.out.println("Введите второе число:");
        double num2 = scanner.nextDouble();

        double sumResult = addNumbers(num1, num2);
        double subtractResult = subtractNumbers(num1, num2);
        double multiplyResult = multiplyNumbers(num1, num2);
        double divideResult = divideNumbers(num1, num2);

        System.out.println("Результат сложения: " + sumResult);
        System.out.println("Результат вычитания: " + subtractResult);
        System.out.println("Результат умножения: " + multiplyResult);
        System.out.println("Результат деления: " + divideResult);

        scanner.close();
    }

    // Метод для сложения двух чисел
    public static double addNumbers(double a, double b) {
        return a + b;
    }

    // Метод для вычитания двух чисел
    public static double subtractNumbers(double a, double b) {
        return a - b;
    }

    // Метод для умножения двух чисел
    public static double multiplyNumbers(double a, double b) {
        return a * b;
    }

    // Метод для деления двух чисел (проверка деления на ноль)
    public static double divideNumbers(double a, double b) {
        if (b == 0) {
            System.out.println("Деление на ноль невозможно.");
            return Double.NaN;
        } else {
            return a / b;
        }
    }
}
//№2
//            Реализовать программу, выводящую на экран результаты:
//            Сложения двух чисел
//            Вычитания двух чисел
//            Умножения двух чисел
//            Деления двух чисел
//            Каждая из арифметических операций должна быть реализована как отдельный метод.

